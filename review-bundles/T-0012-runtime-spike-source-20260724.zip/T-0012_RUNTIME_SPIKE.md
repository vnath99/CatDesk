# T-0012 Runtime Spike

Date: 2026-07-24
Branch: orchestrator/t-0012-feasibility
Base commit: 3e4a512

## Scope

Evaluate whether CatDesk can act as the only file and shell execution authority while an OpenClaw/Ollama worker runtime provides planning, delegation, and model orchestration. This spike is intentionally documentation-only because OpenClaw was not installed locally and the approved boundaries disallowed persistent dependency installation without a separate approval packet.

## Boundaries Applied

- No OpenClaw, Node.js, npm package, system package, service, global PATH, profile, registry, Ollama config, or CatDesk config changes were made.
- No repository secrets, environment variable values, private keys, or tokens were sent to Ollama, OpenClaw, or any model.
- Only localhost Ollama API calls were made, using short synthetic prompts with no private project content.
- CatDesk MCP behavior was exercised through the existing Rust MCP test module, which creates disposable temporary workspaces.
- A live CatDesk HTTP MCP probe was not run because the current TUI startup path requires interactive mode selection, an ngrok auth gate when no token is saved, and a random per-run MCP slug that is not exposed by health output.

## Local Runtime Discovery

OpenClaw:

- `Get-Command openclaw` returned no executable.
- Common user install locations were searched for `openclaw*`; no local OpenClaw binary or shim was found.

Node/npm:

- `Get-Command node` and `Get-Command npm` returned no system executable.
- Common locations under `%APPDATA%`, `%LOCALAPPDATA%`, Program Files, Scoop, Volta, and nvm-style paths did not reveal a separate user/system Node/npm install.
- Codex's bundled runtime does include an isolated Node executable at `C:\Users\Volap\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe`, reporting `v24.14.0`, and a bundled pnpm reporting `11.9.0`. These were not used to install OpenClaw.

Ollama:

- `Get-Command ollama` found `C:\Users\Volap\AppData\Local\Programs\Ollama\ollama.exe`.
- `ollama --version` reported `ollama version is 0.24.0`.
- `ollama list` showed multiple installed local models, including `qwen3.5:9b`.
- `ollama show qwen3.5:9b` reported a Qwen 3.5 9.7B Q4_K_M model with 262144 context length and capabilities including completion, vision, tools, and thinking.

## Ollama/Qwen Probe

Endpoint: `http://127.0.0.1:11434/api/chat`

Model: `qwen3.5:9b`

Findings:

- Basic chat completion succeeded with the expected marker text.
- Tool-call emission succeeded: given a fake tool schema named `get_project_status`, Qwen emitted a structured tool call with JSON arguments.
- Tool-result continuation succeeded with valid JSON tool output.
- Malformed tool output was not reliably escalated. When given a malformed tool result string and instructed to escalate, Qwen rationalized the malformed string instead of rejecting it.

Implication:

Worker prompts may ask for strict escalation, but the runtime must not rely on the model alone to validate tool output. CatDesk/OpenClaw glue should validate required tool-result schemas before the worker sees them, and malformed CatDesk tool results should become deterministic orchestration failures.

## CatDesk MCP Probe

Executed:

```powershell
cargo test mcp::tests -- --nocapture
```

Result:

- 38 MCP tests passed.
- Coverage included JSON-RPC lifecycle, tool listing, read-only mode, no `.catdesk` initialization from read-only tools, plan enforcement, shell chaining rejection, delete dry-run and confirmation flow, verification, Git status warnings, file write/edit/delete widget payloads, project memory, task queue, prompt templates, repo map generation, and run-command behavior.

Live HTTP probe status:

- Not run under the approved safety boundaries.
- Current startup requires TUI input for mode selection.
- Server startup is blocked by ngrok auth setup if no token is already configured.
- The MCP path is generated from a random slug in memory and the health endpoint exposes status, mode, tool mode, and workspace, but not the MCP path.

This is not a CatDesk MCP correctness failure. It is a testability/operability gap for delegated orchestration spikes. A future production change should add an explicitly safe headless local-MCP mode or a test-only endpoint discovery path before attempting automated OpenClaw integration.

## OpenClaw Feasibility

OpenClaw could not be executed because it is not installed. Official documentation indicates the Windows PowerShell installer may install Node if needed and install OpenClaw via npm; Ollama's OpenClaw integration may prompt to install OpenClaw via npm on first launch. Those are persistent dependency changes and were not run.

Relevant official docs reviewed:

- https://docs.openclaw.ai/install
- https://docs.openclaw.ai/install/installer
- https://docs.openclaw.ai/install/uninstall
- https://docs.openclaw.ai/install/node
- https://docs.openclaw.ai/cli/mcp
- https://docs.openclaw.ai/tools
- https://docs.ollama.com/integrations/openclaw

Important OpenClaw constraints observed from docs:

- OpenClaw has native runtime/file/shell-style tools in its own tool catalog.
- OpenClaw MCP configuration supports server-level `toolFilter` include/exclude lists for MCP servers, but this filters MCP-server tools, not necessarily OpenClaw's own native authority.
- OpenClaw tool policy can remove tools before the model call, but this must be verified on an installed runtime before treating CatDesk as the only execution authority.
- OpenClaw's MCP server mode (`openclaw mcp serve`) exposes OpenClaw-routed conversations to an MCP client; OpenClaw's MCP client configuration manages outbound MCP servers.

## Command History

Repository and baseline:

```powershell
git remote -v
git status --short
git switch -c orchestrator/t-0012-feasibility
git log -1 --oneline
cargo fmt --check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
```

Runtime discovery:

```powershell
Get-Command openclaw -ErrorAction SilentlyContinue
Get-Command ollama -ErrorAction SilentlyContinue
Get-Command node -ErrorAction SilentlyContinue
Get-Command npm -ErrorAction SilentlyContinue
Get-ChildItem -Path C:\Users\Volap -Recurse -Filter openclaw* -ErrorAction SilentlyContinue
& 'C:\Users\Volap\AppData\Local\Programs\Ollama\ollama.exe' --version
& 'C:\Users\Volap\AppData\Local\Programs\Ollama\ollama.exe' list
& 'C:\Users\Volap\AppData\Local\Programs\Ollama\ollama.exe' show qwen3.5:9b
& 'C:\Users\Volap\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --version
& 'C:\Users\Volap\.cache\codex-runtimes\codex-primary-runtime\dependencies\bin\fallback\pnpm.cmd' --version
```

Ollama local model probes:

```powershell
curl.exe -s http://127.0.0.1:11434/api/chat -H "Content-Type: application/json" --data-binary @-
```

The posted JSON bodies used synthetic prompts only:

- basic marker completion
- fake `get_project_status` tool-call schema
- valid fake JSON tool result continuation
- malformed fake tool result continuation

CatDesk source inspection and MCP tests:

```powershell
rg -n "PORT|WORKSPACE_ROOT|/mcp|health|bind|serve|listen|Router|post_mcp" src\main.rs src\server.rs src\mcp.rs
Get-Content src\server.rs | Select-Object -First 180
Get-Content src\main.rs | Select-Object -Skip 830 -First 70
Get-Content src\main.rs | Select-Object -Skip 2410 -First 80
Get-Content src\server.rs | Select-Object -Skip 1000 -First 110
rg -n "CATDESK|mcp_path|default_mcp|MCP_PATH|ToolMode|tool_mode" src\main.rs src\state.rs src\mcp.rs
Get-Content src\server.rs | Select-Object -Skip 225 -First 70
Get-Content src\state.rs | Select-Object -Skip 560 -First 70
Get-Content src\state.rs | Select-Object -Skip 110 -First 80
rg -n "fn generate_mcp_slug|mcp_slug" src\state.rs
cargo test mcp::tests -- --nocapture
```

## Recommendation

Do not install or run OpenClaw yet as part of this spike. The next approved implementation step should be a CatDesk-local headless MCP test mode that:

- binds only to `127.0.0.1`;
- uses a caller-provided or printed local-only MCP path;
- skips ngrok entirely;
- supports per-process config/state directories;
- can start in read-only or multi-tools mode explicitly;
- exits cleanly after a test window or on stdin/HTTP shutdown.

After that exists, run a second spike with an explicit OpenClaw installation approval packet and verify whether OpenClaw can fully hide or deny native file/shell/network tools so CatDesk remains the only execution authority.
