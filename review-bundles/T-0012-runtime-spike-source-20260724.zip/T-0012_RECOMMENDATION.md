# T-0012 Recommendation

Date: 2026-07-24

## Decision

Pause OpenClaw integration before installation. Proceed first with a CatDesk-local headless MCP test mode, then repeat the runtime spike with an approved, isolated OpenClaw install plan.

## Why

The current CatDesk safety layer is materially stronger after T-0011, and the existing MCP tests pass. Local Ollama/Qwen can emit structured tool calls. However, OpenClaw is not installed, and official docs show it has native runtime/file-style tools. The core requirement for this project is that CatDesk remains the only file/shell execution authority. That requirement cannot be confirmed from documentation alone.

## Recommended Next Ticket

Add a narrow CatDesk headless local-MCP mode for test and orchestration spikes.

Acceptance criteria:

- Starts without TUI input.
- Binds only to `127.0.0.1` by default.
- Skips ngrok entirely.
- Uses a caller-provided local-only MCP path or prints the generated path to stdout in machine-readable JSON.
- Accepts `WORKSPACE_ROOT`, `PORT`, mode, and tool mode as per-process settings.
- Supports a disposable config/state directory.
- Exits cleanly on signal or explicit shutdown.
- Does not change existing interactive behavior.

Suggested non-production CLI shape:

```powershell
catdesk --headless-mcp --host 127.0.0.1 --port 33200 --workspace C:\Temp\catdesk-disposable --mcp-path /t0012/mcp --mode computer --tool-mode multi-tools --no-ngrok
```

The exact flags can differ, but the behavior should be this constrained.

## Future OpenClaw Approval Packet

Before installing OpenClaw, prepare and approve:

- Exact command.
- Official source URL.
- Version or tag.
- Destination directories.
- Whether Node will be installed or reused.
- Whether npm global prefix, PATH, services, scheduled tasks, or OpenClaw state are changed.
- Dry-run command output when available.
- Rollback command and manual cleanup path.

Candidate official commands to evaluate, not yet approved to run:

```powershell
& ([scriptblock]::Create((iwr -useb https://openclaw.ai/install.ps1))) -Tag latest -NoOnboard -DryRun
```

```powershell
iwr -useb https://openclaw.ai/install.ps1 | iex
```

```powershell
ollama launch openclaw
```

The first command is the only candidate that appears suitable for a pre-install approval packet because it advertises dry-run behavior. The second and third are persistent install/onboarding paths and should not be run without explicit approval.

## Required Runtime Audit After Install

Only after approved installation:

1. Run read-only diagnostics such as `openclaw --version`, `openclaw doctor --lint`, and `openclaw mcp status` if available.
2. Configure a disposable OpenClaw profile/state directory if supported.
3. Register CatDesk as an MCP server only against a disposable CatDesk workspace.
4. Inspect the effective tool list sent to the worker.
5. Confirm native OpenClaw file/shell/network/browser tools are absent or denied.
6. Confirm CatDesk tools are the only available file/shell execution path.
7. Send synthetic prompts only.
8. Verify malformed CatDesk tool results are rejected by glue/schema validation before model continuation.

## Stop Conditions

Treat the integration as infeasible until redesigned if:

- OpenClaw cannot disable or deny native file/shell/runtime tools for the worker.
- OpenClaw requires persistent global config or service changes for a disposable local test.
- Tool policy cannot be inspected before the model call.
- CatDesk cannot be started in a deterministic local-only MCP mode.
- The worker can reach secrets, environment values, private keys, or non-disposable repositories outside CatDesk-mediated tools.
