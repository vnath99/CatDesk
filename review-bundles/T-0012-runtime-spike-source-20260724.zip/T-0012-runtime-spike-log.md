# T-0012 Runtime Spike Review Log

Date: 2026-07-24
Branch: orchestrator/t-0012-feasibility

## Chat Summary

User approved the T-0012 runtime spike under a restricted scope:

- no OpenClaw, Node.js, npm package, system package, or persistent dependency installation without a separate approval packet;
- first search for existing OpenClaw, Node, and npm installations outside PATH;
- prefer temporary, isolated, reversible tests;
- do not change global PATH, shell profiles, registry, services, Ollama config, or existing CatDesk config;
- use only disposable repositories/workspaces for experimental calls;
- do not send secrets, credential values, tokens, or private keys to a model;
- keep CatDesk as the only intended file/shell authority;
- documentation-only changes approved;
- run fmt, clippy, and tests after edits;
- do not commit, push, open a PR, or merge.

## Commands Run

Baseline:

```powershell
git remote -v
git status --short
git switch -c orchestrator/t-0012-feasibility
git log -1 --oneline
cargo fmt --check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
```

Runtime discovery:

```powershell
Get-Command openclaw -ErrorAction SilentlyContinue
Get-Command ollama -ErrorAction SilentlyContinue
Get-Command node -ErrorAction SilentlyContinue
Get-Command npm -ErrorAction SilentlyContinue
Get-ChildItem -Path C:\Users\Volap -Recurse -Filter openclaw* -ErrorAction SilentlyContinue
& 'C:\Users\Volap\AppData\Local\Programs\Ollama\ollama.exe' --version
& 'C:\Users\Volap\AppData\Local\Programs\Ollama\ollama.exe' list
& 'C:\Users\Volap\AppData\Local\Programs\Ollama\ollama.exe' show qwen3.5:9b
& 'C:\Users\Volap\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --version
& 'C:\Users\Volap\.cache\codex-runtimes\codex-primary-runtime\dependencies\bin\fallback\pnpm.cmd' --version
```

Ollama probes:

```powershell
curl.exe -s http://127.0.0.1:11434/api/chat -H "Content-Type: application/json" --data-binary @-
```

Synthetic prompt bodies only:

- basic local completion marker;
- fake `get_project_status` tool schema;
- valid fake tool result continuation;
- malformed fake tool result continuation.

Source inspection:

```powershell
rg -n "PORT|WORKSPACE_ROOT|/mcp|health|bind|serve|listen|Router|post_mcp" src\main.rs src\server.rs src\mcp.rs
Get-Content src\server.rs | Select-Object -First 180
Get-Content src\main.rs | Select-Object -Skip 830 -First 70
Get-Content src\main.rs | Select-Object -Skip 2410 -First 80
Get-Content src\server.rs | Select-Object -Skip 1000 -First 110
rg -n "CATDESK|mcp_path|default_mcp|MCP_PATH|ToolMode|tool_mode" src\main.rs src\state.rs src\mcp.rs
Get-Content src\server.rs | Select-Object -Skip 225 -First 70
Get-Content src\state.rs | Select-Object -Skip 560 -First 70
Get-Content src\state.rs | Select-Object -Skip 110 -First 80
rg -n "fn generate_mcp_slug|mcp_slug" src\state.rs
```

MCP disposable-workspace tests:

```powershell
cargo test mcp::tests -- --nocapture
```

Final verification:

```powershell
cargo fmt --check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
git status --short
```

## Findings

- OpenClaw is not installed locally.
- System Node/npm are not available locally through PATH or common install locations.
- Codex has a bundled Node/pnpm runtime, but it was not used for dependency installation.
- Ollama is installed and `qwen3.5:9b` is available with tool-call capability.
- Qwen emitted structured tool calls and continued from valid tool results.
- Qwen did not reliably escalate malformed tool output; schema validation must be deterministic outside the model.
- CatDesk MCP tests passed.
- Live HTTP CatDesk MCP probing should wait for a headless local-only mode because the current TUI startup path, ngrok auth gate, and hidden random MCP slug make automation unsafe under the approved boundaries.

## Files Included In Review Bundle

- `docs/orchestrator/T-0012_RUNTIME_SPIKE.md`
- `docs/orchestrator/T-0012_RUNTIME_COMPARISON.md`
- `docs/orchestrator/T-0012_RECOMMENDATION.md`
- `docs/orchestrator/tickets/T-0012.md`
- `review-bundles/T-0012-runtime-spike-log.md`

## Verification Results

- `cargo fmt --check`: passed
- `cargo clippy --all-targets --all-features -- -D warnings`: passed
- `cargo test`: passed, 110 tests

## Recommendation

Do not install OpenClaw yet. Add a constrained CatDesk headless local-MCP mode first, then perform a second approved OpenClaw runtime audit against a disposable workspace.
