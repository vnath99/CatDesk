# T-0012 Runtime Comparison

Date: 2026-07-24

## Candidates

### CatDesk Direct MCP

Status: present and tested through existing Rust MCP tests.

Strengths:

- Owns file and shell execution boundaries locally.
- Has project memory, planning, verification, Git workflow, delete confirmation, shell allowlist, and read-only modes.
- Existing tests cover many of the safety surfaces needed for a delegated runtime.

Weaknesses:

- Current application startup is TUI-first.
- Local HTTP MCP automation is difficult because the MCP path is randomized and not exposed by health output.
- Server startup is coupled to ngrok auth/setup.
- No explicit headless local-only runtime mode exists for automated orchestrator testing.

### Ollama with Qwen 3.5 Local Model

Status: available locally and probed through localhost API.

Strengths:

- `qwen3.5:9b` is installed and supports tool-call output.
- Tool-call JSON emission works on a synthetic request.
- Tool-result continuation works with valid synthetic JSON.
- Localhost-only tests avoided private repo content and secrets.

Weaknesses:

- The model did not reliably reject malformed tool output when prompted to escalate.
- Any delegated-worker design needs deterministic schema validation outside the model.
- Tool-calling quality should be re-tested with the exact OpenClaw prompt/runtime shape before production use.

### OpenClaw Runtime

Status: not installed; documentation-only assessment.

Potential strengths:

- Designed as a personal assistant gateway with model routing, channels, agents, tool policy, MCP support, and Ollama integration.
- Official docs show MCP server mode, outbound MCP server configuration, tool filters for MCP servers, and policy mechanisms that can remove tools before model calls.
- Ollama integration can launch OpenClaw and configure models.

Blocking uncertainties:

- OpenClaw's own native file/shell/runtime tools must be disabled or denied before CatDesk can be considered the only execution authority.
- Documentation shows native runtime and file tools exist in the OpenClaw catalog, so a configured runtime audit is required.
- Installation on this Windows host is persistent and may install Node/OpenClaw via npm.
- OpenClaw is absent locally, so `openclaw doctor --lint`, `openclaw mcp probe`, `openclaw mcp tools`, and effective tool-policy checks could not be run.

## Comparison Matrix

| Area | CatDesk Direct MCP | Ollama/Qwen | OpenClaw |
| --- | --- | --- | --- |
| Installed locally | Yes | Yes | No |
| Persistent changes needed for spike | No | No | Yes, unless already installed later |
| Tool-call support | Yes, MCP JSON-RPC | Yes, model emits tool calls | Expected, not verified locally |
| File/shell authority | CatDesk-owned | None by itself | Native authority exists unless disabled |
| Safety controls | Strong and tested | Prompt-dependent | Policy-based, needs runtime audit |
| Headless automation | Not yet clean | Yes via HTTP API | Unknown until installed |
| Main risk | Startup/testability coupling | Malformed tool-result tolerance | Authority boundary drift |

## Feasibility Judgment

The architecture remains plausible, but it is not yet proven. CatDesk has the right safety primitives, and local Qwen can emit tool calls. The missing proof is whether OpenClaw can be configured so the worker sees only CatDesk MCP tools and cannot use native OpenClaw file/shell/network tools. Until that is verified on an installed runtime, OpenClaw must be treated as an unproven orchestration layer rather than a safe execution boundary.
